﻿using System;

namespace PruebasTDD
{
    class Program
    {
        static void Main(string[] args)
        {
            var validator = new ISBNValidator();
            string input;

            while (true)
            {
                Console.WriteLine("Ingrese un número ISBN (o escriba 'salir' para terminar):");
                input = Console.ReadLine();

                if (input.ToLower() == "salir")
                {
                    break; // Sale del bucle si el usuario escribe "salir"
                }

                bool isValid = validator.Validate(input);
                Console.WriteLine($"El número ISBN es {(isValid ? "válido" : "inválido")}.");
            }

            Console.WriteLine("Gracias por usar el validador de ISBN. Presione cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}