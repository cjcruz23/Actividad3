﻿namespace PruebasTDD
{
    public class ISBNValidator
    {
        public bool Validate(string isbn)
        {
            if (isbn.Length == 10)
            {
                return ValidateISBN10(isbn);
            }
            else if (isbn.Length == 13)
            {
                return ValidateISBN13(isbn);
            }
            return false;
        }

        private bool ValidateISBN10(string isbn)
        {
            int sum = 0;
            for (int i = 0; i < 10; i++)
            {
                if (i == 9 && isbn[i] == 'X')
                {
                    sum += 10; // 'X' representa 10
                }
                else if (char.IsDigit(isbn[i]))
                {
                    sum += (isbn[i] - '0') * (10 - i);
                }
                else
                {
                    return false; // Carácter inválido
                }
            }
            return sum % 11 == 0;
        }

        private bool ValidateISBN13(string isbn)
        {
            int sum = 0;
            for (int i = 0; i < 13; i++)
            {
                if (!char.IsDigit(isbn[i]))
                {
                    return false; // Carácter inválido
                }
                sum += (isbn[i] - '0') * (i % 2 == 0 ? 1 : 3);
            }
            return sum % 10 == 0;
        }
    }
}
