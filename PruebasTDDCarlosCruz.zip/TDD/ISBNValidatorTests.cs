﻿using NUnit.Framework;
using PruebasTDD;
namespace TDD
{

    [TestFixture]
    public class ISBNValidatorTests
    {
        private ISBNValidator _validator;

        [SetUp]
        public void SetUp()
        {
            _validator = new ISBNValidator();
        }

        [Test]
        public void Validate_ISBN10_Valid()
        {
            Assert.That(_validator.Validate("0306406152"), Is.True);
        }


        [Test]
        public void Validate_ISBN13_Valid()
        {
            Assert.That(_validator.Validate("9780306406157"), Is.True);
        }

        [Test]
        public void Validate_ISBN13_Invalid()
        {
            Assert.That(_validator.Validate("9780306406150"), Is.False);
        }
    }
}


